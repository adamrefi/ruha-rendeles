const Joi = require('joi');

const userValidation = (user) => {
    const schema = Joi.object({
        name: Joi.string().min(3).max(255).required(),
        email: Joi.string().email().required(),
        password: Joi.string().min(6).required(),
        address: Joi.string().required(),
        phone: Joi.string().min(10).max(15).required()
    });
    return schema.validate(user);
};

const productValidation = (product) => {
    const schema = Joi.object({
        name: Joi.string().min(3).max(255).required(),
        description: Joi.string().required(),
        price: Joi.number().positive().required(),
        stock: Joi.number().integer().min(0).required(),
        category: Joi.string().required(),
        image_url: Joi.string().uri().required()
    });
    return schema.validate(product);
};

const orderValidation = (order) => {
    const schema = Joi.object({
        user_id: Joi.number().integer().required(),
        total_price: Joi.number().positive().required(),
        status: Joi.string().valid('Pending', 'Completed', 'Cancelled').default('Pending')
    });
    return schema.validate(order);
};

const orderItemValidation = (orderItem) => {
    const schema = Joi.object({
        order_id: Joi.number().integer().required(),
        product_id: Joi.number().integer().required(),
        quantity: Joi.number().integer().min(1).required(),
        price: Joi.number().positive().required()
    });
    return schema.validate(orderItem);
};

const paymentValidation = (payment) => {
    const schema = Joi.object({
        order_id: Joi.number().integer().required(),
        payment_method: Joi.string().valid('Credit Card', 'PayPal', 'Bank Transfer').required(),
        transaction_id: Joi.string().required(),
        status: Joi.string().valid('Processing', 'Completed', 'Failed').default('Processing')
    });
    return schema.validate(payment);
};

const reviewValidation = (review) => {
    const schema = Joi.object({
        user_id: Joi.number().integer().required(),
        product_id: Joi.number().integer().required(),
        rating: Joi.number().integer().min(1).max(5).required(),
        comment: Joi.string().allow('').optional()
    });
    return schema.validate(review);
};

const wishlistValidation = (wishlist) => {
    const schema = Joi.object({
        user_id: Joi.number().integer().required(),
        product_id: Joi.number().integer().required()
    });
    return schema.validate(wishlist);
};

const couponValidation = (coupon) => {
    const schema = Joi.object({
        code: Joi.string().min(5).max(20).required(),
        discount: Joi.number().positive().max(100).required(),
        expiration_date: Joi.date().required(),
        min_order_value: Joi.number().positive().required()
    });
    return schema.validate(coupon);
};

const shippingValidation = (shipping) => {
    const schema = Joi.object({
        order_id: Joi.number().integer().required(),
        carrier: Joi.string().required(),
        tracking_number: Joi.string().optional(),
        estimated_delivery: Joi.date().required(),
        status: Joi.string().valid('Processing', 'Shipped', 'Delivered').default('Processing')
    });
    return schema.validate(shipping);
};

const adminValidation = (admin) => {
    const schema = Joi.object({
        name: Joi.string().min(3).max(255).required(),
        email: Joi.string().email().required(),
        password: Joi.string().min(6).required(),
        role: Joi.string().valid('Super Admin', 'Manager').required()
    });
    return schema.validate(admin);
};

module.exports = {
    userValidation,
    productValidation,
    orderValidation,
    orderItemValidation,
    paymentValidation,
    reviewValidation,
    wishlistValidation,
    couponValidation,
    shippingValidation,
    adminValidation
};
